Patch pkg_resources to remove dependency on ``jaraco.text``.
