Update pkg_resources (via setuptools) to 65.6.3
